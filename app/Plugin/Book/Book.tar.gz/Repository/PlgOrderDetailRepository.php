<?php

namespace Plugin\Book\Repository;

use Doctrine\ORM\EntityRepository;

class PlgOrderDetailRepository extends EntityRepository
{
}

